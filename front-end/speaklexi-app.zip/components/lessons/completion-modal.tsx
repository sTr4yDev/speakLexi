"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Trophy, Zap, Star } from "lucide-react"

interface CompletionModalProps {
  lessonTitle: string
  xpEarned: number
  onClose: () => void
}

export function CompletionModal({ lessonTitle, xpEarned, onClose }: CompletionModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
      <Card className="mx-4 w-full max-w-md p-8">
        <div className="text-center">
          {/* Success Icon */}
          <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-success/10">
            <Trophy className="h-10 w-10 text-success" />
          </div>

          {/* Title */}
          <h2 className="mb-2 text-3xl font-bold text-balance">Lección Completada</h2>
          <p className="mb-6 text-muted-foreground">Has completado: {lessonTitle}</p>

          {/* Rewards */}
          <div className="mb-8 space-y-4">
            <div className="flex items-center justify-center gap-3 rounded-xl bg-accent/10 p-4">
              <Zap className="h-6 w-6 text-accent" />
              <div className="text-left">
                <p className="text-sm text-muted-foreground">XP Ganado</p>
                <p className="text-2xl font-bold text-accent">+{xpEarned}</p>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 rounded-xl bg-primary/10 p-4">
              <Star className="h-6 w-6 text-primary" />
              <div className="text-left">
                <p className="text-sm text-muted-foreground">Racha Mantenida</p>
                <p className="text-xl font-bold text-primary">7 días</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-3">
            <Button onClick={onClose} className="w-full">
              Continuar Aprendiendo
            </Button>
            <Button variant="outline" onClick={onClose} className="w-full bg-transparent">
              Ver Progreso
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}
