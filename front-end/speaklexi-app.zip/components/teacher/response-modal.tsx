"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Send } from "lucide-react"

interface Feedback {
  id: number
  student: string
  type: string
  message: string
  date: string
  status: string
  response: string | null
}

interface ResponseModalProps {
  isOpen: boolean
  onClose: () => void
  feedback?: Feedback
}

export function ResponseModal({ isOpen, onClose, feedback }: ResponseModalProps) {
  const [response, setResponse] = useState(feedback?.response || "")
  const { toast } = useToast()

  const handleSubmit = () => {
    if (!response.trim()) {
      toast({
        title: "Respuesta vacía",
        description: "Por favor escribe una respuesta antes de enviar",
        variant: "destructive",
      })
      return
    }

    toast({
      title: "Respuesta enviada",
      description: "El estudiante ha sido notificado de tu respuesta",
    })
    setResponse("")
    onClose()
  }

  if (!feedback) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {feedback.status === "respondido" ? "Respuesta Enviada" : "Responder Retroalimentación"}
          </DialogTitle>
          <DialogDescription>Retroalimentación de {feedback.student}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-lg border p-4">
            <div className="mb-2 flex items-center gap-2">
              <span className="font-medium">{feedback.student}</span>
              <Badge
                variant={
                  feedback.type === "problema"
                    ? "destructive"
                    : feedback.type === "felicitacion"
                      ? "default"
                      : "secondary"
                }
              >
                {feedback.type}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">{feedback.message}</p>
            <p className="mt-2 text-xs text-muted-foreground">{feedback.date}</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="response">
              {feedback.status === "respondido" ? "Tu Respuesta" : "Escribe tu respuesta"}
            </Label>
            <Textarea
              id="response"
              placeholder="Escribe tu respuesta aquí..."
              value={response}
              onChange={(e) => setResponse(e.target.value)}
              rows={6}
              disabled={feedback.status === "respondido"}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            {feedback.status === "respondido" ? "Cerrar" : "Cancelar"}
          </Button>
          {feedback.status !== "respondido" && (
            <Button onClick={handleSubmit}>
              <Send className="mr-2 h-4 w-4" />
              Enviar Respuesta
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
