import { DashboardHeader } from "@/components/dashboard/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus, Calendar, Target, BookOpen, Clock } from "lucide-react"
import Link from "next/link"

export default function PlanningPage() {
  const plans = [
    {
      id: 1,
      title: "Unidad 5: Tiempos Verbales",
      course: "Inglés Intermedio",
      level: "B1",
      objectives: 3,
      resources: 8,
      status: "en_progreso",
      dueDate: "15 Feb 2025",
    },
    {
      id: 2,
      title: "Módulo de Conversación",
      course: "Inglés Avanzado",
      level: "C1",
      objectives: 5,
      resources: 12,
      status: "planificado",
      dueDate: "28 Feb 2025",
    },
    {
      id: 3,
      title: "Gramática Básica",
      course: "Inglés Principiante",
      level: "A1",
      objectives: 4,
      resources: 10,
      status: "completado",
      dueDate: "10 Ene 2025",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/5">
      <DashboardHeader />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-balance">Planificación de Contenidos</h1>
            <p className="mt-1 text-muted-foreground">Organiza y planifica nuevos contenidos educativos</p>
          </div>
          <Link href="/profesor/planificacion/nuevo">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Nueva Planificación
            </Button>
          </Link>
        </div>

        {/* Stats */}
        <div className="mb-6 grid gap-4 md:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Planes</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">Este semestre</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">En Progreso</CardTitle>
              <Clock className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">5</div>
              <p className="text-xs text-muted-foreground">Activos</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completados</CardTitle>
              <Target className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">7</div>
              <p className="text-xs text-muted-foreground">Finalizados</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Próximos</CardTitle>
              <Calendar className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">Este mes</p>
            </CardContent>
          </Card>
        </div>

        {/* Plans List */}
        <Card>
          <CardHeader>
            <CardTitle>Planes de Contenido</CardTitle>
            <CardDescription>Gestiona tus planificaciones de contenido educativo</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {plans.map((plan) => (
                <Card key={plan.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="mb-2 flex items-center gap-2">
                          <h3 className="font-semibold">{plan.title}</h3>
                          <Badge
                            variant={
                              plan.status === "completado"
                                ? "default"
                                : plan.status === "en_progreso"
                                  ? "secondary"
                                  : "outline"
                            }
                            className={
                              plan.status === "en_progreso"
                                ? "bg-blue-100 text-blue-700"
                                : plan.status === "completado"
                                  ? "bg-green-100 text-green-700"
                                  : ""
                            }
                          >
                            {plan.status.replace("_", " ")}
                          </Badge>
                        </div>
                        <div className="mb-3 flex items-center gap-4 text-sm text-muted-foreground">
                          <span>
                            {plan.course} - {plan.level}
                          </span>
                          <span className="flex items-center gap-1">
                            <Target className="h-3 w-3" />
                            {plan.objectives} objetivos
                          </span>
                          <span className="flex items-center gap-1">
                            <BookOpen className="h-3 w-3" />
                            {plan.resources} recursos
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {plan.dueDate}
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline">
                          Ver Detalles
                        </Button>
                        {plan.status !== "completado" && (
                          <Button size="sm" variant="default">
                            Continuar
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
